package dao.objetXML;

import java.util.List;

import dao.DAO;
import dao.objet.AbonnementDAO;
import modele.Abonnement;

public class XMLAbonnementDAO implements DAO<Abonnement> {


    public static AbonnementDAO getInstance() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Abonnement getById(int id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean create(Abonnement objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean update(Abonnement objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean delete(Abonnement objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public List<Abonnement> getAll() {
        // TODO Auto-generated method stub
        return null;
    }


}
