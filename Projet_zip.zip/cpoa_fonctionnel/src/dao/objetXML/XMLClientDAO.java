package dao.objetXML;

import java.util.List;

import dao.DAO;
import modele.Client;

public class XMLClientDAO implements DAO<Client> {

    @Override
    public Client getById(int id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean create(Client objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean update(Client objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean delete(Client objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public List<Client> getAll() {
        // TODO Auto-generated method stub
        return null;
    }

}
