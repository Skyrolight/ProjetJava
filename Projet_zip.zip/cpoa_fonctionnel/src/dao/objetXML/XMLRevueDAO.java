package dao.objetXML;

import java.util.List;

import dao.DAO;
import modele.Revue;

public class XMLRevueDAO implements DAO<Revue> {

    @Override
    public Revue getById(int id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean create(Revue objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean update(Revue objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean delete(Revue objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public List<Revue> getAll() {
        // TODO Auto-generated method stub
        return null;
    }

}
