package dao.objetXML;

import java.util.List;

import dao.DAO;
import modele.Periodicite;

public class XMLPeriodiciteDAO implements DAO<Periodicite> {

    @Override
    public Periodicite getById(int id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean create(Periodicite objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean update(Periodicite objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean delete(Periodicite objet) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public List<Periodicite> getAll() {
        // TODO Auto-generated method stub
        return null;
    }

}
